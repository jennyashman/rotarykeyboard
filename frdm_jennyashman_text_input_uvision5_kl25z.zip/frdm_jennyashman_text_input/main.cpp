#include "mbed.h"
#include "USBKeyboard.h"

AnalogIn potentiometer(A0);
PwmOut led(LED1);
char str[10];
DigitalIn selectButton(D2);
DigitalIn spaceButton(D3);
DigitalIn deleteButton(D4);

Serial pc(USBTX, USBRX);
USBKeyboard keyboard;

float map(float x, float in_min, float in_max, float out_min, float out_max)
{
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

int main() 
{
    selectButton.mode(PullUp);
    spaceButton.mode(PullUp);
    deleteButton.mode(PullUp);
    led.period(0.001);
    while(1) 
    {
        led=(float)(potentiometer);
        float val = map(potentiometer, 0.00,1.00,0.00,2000.00);
        sprintf(str, "%d \n", (int)val);
        
        pc.printf(str);
        
        if (spaceButton)
        {
            keyboard.keyCode(' ', 0);
            wait(0.50);
        }
        
        if (deleteButton)
        {
            keyboard.keyCode('H', 1);
            wait(0.50);
        }
        
        if (selectButton)
        {
            if(val>27&&val<32)
            {
                pc.printf("A");
                keyboard.keyCode('a', 0);  
            }
            if(val>33&&val<40)
            {
                pc.printf("B");
                keyboard.keyCode('b', 0);
            }
             if(val>39&val<44)
            {
                pc.printf("C");
                keyboard.keyCode('c', 0);
            }
             if(val>45&&val<50)
            {
                pc.printf("D");
                keyboard.keyCode('d', 0);
            }
             if(val>50&&val<56)
            {
                pc.printf("E");
                keyboard.keyCode('e', 0);
            }
             if(val>56&&val<62)
            {
                pc.printf("F");
                keyboard.keyCode('f', 0);
            }
             if(val>62&&val<69)
            {
                pc.printf("G");
                keyboard.keyCode('g', 0);
            }
             if(val>69&&val<74)
            {
                pc.printf("H");
                keyboard.keyCode('h', 0);
            }
             if(val>74&&val<81)
            {
                pc.printf("I");
                keyboard.keyCode('i', 0);
            }
             if(val>81&&val<86)
            {
                pc.printf("J");
                keyboard.keyCode('j', 0);
            }
             if(val>86&&val<93)
            {
                pc.printf("K");
                keyboard.keyCode('k', 0);
            }
             if(val>93&&val<98)
            {
                pc.printf("L");
                keyboard.keyCode('l', 0);
            }
             if(val>98&&val<104)
            {
                pc.printf("M");
                keyboard.keyCode('m', 0);
            }
             if(val>104&&val<110)
            {
                pc.printf("N");
                keyboard.keyCode('n', 0);
            }
             if(val>110&&val<117)
            {
                pc.printf("O");
                keyboard.keyCode('o', 0);
            }
             if(val>117&&val<123)
            {
                pc.printf("P");
                keyboard.keyCode('p', 0);
            }
             if(val>123&&val<130)
            {
                pc.printf("Q");
                keyboard.keyCode('q', 0);
            }
             if(val>130&&val<135)
            {
                pc.printf("R");
                keyboard.keyCode('r', 0);
            }
             if(val>135&&val<141)
            {
                pc.printf("S");
                keyboard.keyCode('s', 0);
            }
             if(val>141&&val<148)
            {
                pc.printf("T");
                keyboard.keyCode('t', 0);
            }
             if(val>148&&val<153)
            {
                pc.printf("U");
                keyboard.keyCode('u', 0);
            }
             if(val>153&&val<159)
            {
                pc.printf("V");
                keyboard.keyCode('v', 0);
            } 
            if(val>159&&val<165)
            {
                pc.printf("W");
                keyboard.keyCode('w', 0);
            }
             if(val>165&&val<170)
            {
                pc.printf("X");
                keyboard.keyCode('x', 0);
            }
             if(val>170&&val<176)
            {
                pc.printf("Y");
                keyboard.keyCode('y', 0);
            }
             if(val>179&&val<183)
            {
                pc.printf("Z");
                keyboard.keyCode('z', 0);
            }
               }     
            wait(0.30);
        }
}